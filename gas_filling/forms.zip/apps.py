from django.apps import AppConfig


class GasFillingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gas_filling'
